import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { 
  Wallet, 
  Coins, 
  TrendingUp, 
  Lock, 
  Globe, 
  Pickaxe, 
  BookOpen,
  AlertTriangle,
  CheckCircle,
  ExternalLink,
  RefreshCw,
  Download
} from 'lucide-react'
import './App.css'

// Import ethers with proper error handling for web environment
let ethers;
try {
  // Try to import ethers from CDN if available
  if (typeof window !== 'undefined' && window.ethers) {
    ethers = window.ethers;
  } else {
    // Fallback for bundled environments
    ethers = require('ethers');
  }
} catch (error) {
  console.warn('Ethers.js not available, using fallback methods');
}

function App() {
  // حالة الاتصال بالمحفظة
  const [walletConnected, setWalletConnected] = useState(false)
  const [userAddress, setUserAddress] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [walletStatus, setWalletStatus] = useState('checking')
  
  // حالة اللعبة
  const [gameData, setGameData] = useState({
    balance: 0,
    level: 1,
    experience: 0,
    minedCoins: 0,
    stakedAmount: 0,
    pendingRewards: 0,
    canMine: true,
    publicKey: '0x742d35Cc6634C0532925a3b8D0F4E7C87',
    privateKey: 'abc123def456ghi789jkl012mno345pqr678stu901vwx234yz'
  })
  
  const [activeTab, setActiveTab] = useState('tutorial')
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [manualAddress, setManualAddress] = useState('')
  const [showManualConnect, setShowManualConnect] = useState(false)

  // الأقسام مع الألوان
  const tabs = [
    { id: 'tutorial', name: 'الدليل التعليمي', color: 'bg-green-500', icon: BookOpen },
    { id: 'wallet', name: 'المحفظة', color: 'bg-blue-500', icon: Wallet },
    { id: 'earning', name: 'الكسب', color: 'bg-yellow-500', icon: Coins },
    { id: 'staking', name: 'التخزين', color: 'bg-purple-500', icon: Lock },
    { id: 'network', name: 'الشبكة', color: 'bg-teal-500', icon: Globe },
    { id: 'mining', name: 'التعدين', color: 'bg-red-500', icon: Pickaxe },
    { id: 'blockchain', name: 'البلوك تشين', color: 'bg-gray-500', icon: TrendingUp }
  ]

  // فحص توفر المحفظة
  useEffect(() => {
    checkWalletAvailability()
  }, [])

  const checkWalletAvailability = () => {
    // فحص متعدد للمحافظ المختلفة
    const hasMetaMask = typeof window.ethereum !== 'undefined' && window.ethereum.isMetaMask
    const hasEthereum = typeof window.ethereum !== 'undefined'
    const hasWeb3 = typeof window.web3 !== 'undefined'
    
    console.log('فحص المحافظ:', {
      hasMetaMask,
      hasEthereum,
      hasWeb3,
      userAgent: navigator.userAgent,
      ethersAvailable: !!ethers
    })

    if (hasMetaMask) {
      setWalletStatus('metamask')
      console.log('MetaMask متوفر')
    } else if (hasEthereum) {
      setWalletStatus('ethereum')
      console.log('محفظة Ethereum متوفرة')
    } else {
      setWalletStatus('unavailable')
      console.log('لا توجد محفظة متوفرة')
    }
  }

  // ربط المحفظة المحسن مع دعم ethers.js
  const connectWallet = async () => {
    setIsLoading(true)
    setError('')
    setSuccess('')

    try {
      // فحص توفر المحفظة
      if (!window.ethereum) {
        throw new Error('لا توجد محفظة مثبتة')
      }

      console.log('بدء الاتصال بالمحفظة...')

      // طريقة بسيطة للاتصال
      const accounts = await window.ethereum.request({
        method: 'eth_requestAccounts'
      })

      if (accounts && accounts.length > 0) {
        const address = accounts[0]
        console.log('تم الاتصال بالعنوان:', address)
        
        // التحقق من الشبكة والتبديل إلى Polygon إذا لزم الأمر
        await ensurePolygonNetwork()
        
        setUserAddress(address)
        setWalletConnected(true)
        setSuccess('تم ربط المحفظة بنجاح! 🎉')
        
        // تحديث بيانات اللعبة
        await updateGameData(address)
      } else {
        throw new Error('لم يتم العثور على حسابات')
      }

    } catch (error) {
      console.error('خطأ في الاتصال:', error)
      
      if (error.code === 4001) {
        setError('تم إلغاء الاتصال من قبل المستخدم')
      } else if (error.code === -32002) {
        setError('يوجد طلب اتصال معلق. يرجى فحص المحفظة.')
      } else {
        setError(`خطأ في الاتصال: ${error.message}`)
      }
    }

    setIsLoading(false)
  }

  // التأكد من الاتصال بشبكة Polygon
  const ensurePolygonNetwork = async () => {
    try {
      const chainId = await window.ethereum.request({ method: 'eth_chainId' })
      const polygonChainId = '0x89' // 137 in hex
      
      if (chainId !== polygonChainId) {
        try {
          await window.ethereum.request({
            method: 'wallet_switchEthereumChain',
            params: [{ chainId: polygonChainId }],
          })
        } catch (switchError) {
          // إذا لم تكن الشبكة مضافة، أضفها
          if (switchError.code === 4902) {
            await window.ethereum.request({
              method: 'wallet_addEthereumChain',
              params: [{
                chainId: polygonChainId,
                chainName: 'Polygon Mainnet',
                nativeCurrency: {
                  name: 'MATIC',
                  symbol: 'MATIC',
                  decimals: 18
                },
                rpcUrls: ['https://polygon-rpc.com/'],
                blockExplorerUrls: ['https://polygonscan.com/']
              }]
            })
          }
        }
      }
    } catch (error) {
      console.warn('تحذير: فشل في التبديل إلى شبكة Polygon:', error)
    }
  }

  // قطع الاتصال
  const disconnectWallet = () => {
    setWalletConnected(false)
    setUserAddress('')
    setSuccess('تم قطع الاتصال بالمحفظة')
  }

  // تحديث بيانات اللعبة مع دعم ethers.js
  const updateGameData = async (address) => {
    try {
      // محاولة الحصول على الرصيد الحقيقي إذا كان ethers متوفر
      let realBalance = 0
      
      if (ethers && window.ethereum) {
        try {
          const provider = new ethers.BrowserProvider(window.ethereum)
          const balance = await provider.getBalance(address)
          realBalance = parseFloat(ethers.formatEther(balance))
          console.log('الرصيد الحقيقي:', realBalance, 'MATIC')
        } catch (error) {
          console.warn('فشل في الحصول على الرصيد الحقيقي:', error)
        }
      }
      
      // محاكاة البيانات مع دمج الرصيد الحقيقي
      setGameData(prev => ({
        ...prev,
        balance: realBalance > 0 ? Math.floor(realBalance * 1000) : Math.floor(Math.random() * 1000) + 100,
        level: Math.floor(Math.random() * 10) + 1,
        experience: Math.floor(Math.random() * 5000),
        minedCoins: Math.floor(Math.random() * 500),
        stakedAmount: Math.floor(Math.random() * 200),
        pendingRewards: Math.floor(Math.random() * 50) + 10,
        publicKey: address
      }))
    } catch (error) {
      console.error('خطأ في تحديث البيانات:', error)
      // fallback للبيانات الوهمية
      setGameData(prev => ({
        ...prev,
        balance: Math.floor(Math.random() * 1000) + 100,
        level: Math.floor(Math.random() * 10) + 1,
        experience: Math.floor(Math.random() * 5000),
        minedCoins: Math.floor(Math.random() * 500),
        stakedAmount: Math.floor(Math.random() * 200),
        pendingRewards: Math.floor(Math.random() * 50) + 10,
        publicKey: address
      }))
    }
  }

  // تعدين العملات
  const mineCoins = async () => {
    if (!walletConnected) {
      setError('يرجى ربط المحفظة أولاً')
      return
    }

    setIsLoading(true)
    setError('')

    try {
      // محاكاة التعدين
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      const reward = Math.floor(Math.random() * 10) + 1
      setGameData(prev => ({
        ...prev,
        balance: prev.balance + reward,
        minedCoins: prev.minedCoins + reward,
        experience: prev.experience + reward * 10
      }))
      
      setSuccess(`تم تعدين ${reward} عملة بنجاح! 🎉`)
    } catch (error) {
      setError('فشل في التعدين')
    }

    setIsLoading(false)
  }

  // تخزين العملات
  const stakeCoins = async (amount) => {
    if (!walletConnected) {
      setError('يرجى ربط المحفظة أولاً')
      return
    }

    if (gameData.balance < amount) {
      setError('رصيد غير كافي للتخزين')
      return
    }

    setIsLoading(true)
    setError('')

    try {
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      setGameData(prev => ({
        ...prev,
        balance: prev.balance - amount,
        stakedAmount: prev.stakedAmount + amount
      }))
      
      setSuccess(`تم تخزين ${amount} عملة بنجاح! 💎`)
    } catch (error) {
      setError('فشل في التخزين')
    }

    setIsLoading(false)
  }

  // سحب المكافآت
  const claimRewards = async () => {
    if (!walletConnected) {
      setError('يرجى ربط المحفظة أولاً')
      return
    }

    if (gameData.pendingRewards === 0) {
      setError('لا توجد مكافآت للسحب')
      return
    }

    setIsLoading(true)
    setError('')

    try {
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      const rewards = gameData.pendingRewards
      setGameData(prev => ({
        ...prev,
        balance: prev.balance + rewards,
        pendingRewards: 0
      }))
      
      setSuccess(`تم سحب ${rewards} عملة كمكافآت! 💰`)
    } catch (error) {
      setError('فشل في سحب المكافآت')
    }

    setIsLoading(false)
  }

  // فتح رابط تحميل المحفظة
  const openWalletDownload = (walletType = 'metamask') => {
    // اكتشاف نوع الجهاز
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent)
    const isAndroid = /Android/i.test(navigator.userAgent)
    
    console.log('فتح رابط التحميل:', { walletType, isMobile, isIOS, isAndroid })
    
    let url = ''
    
    if (walletType === 'metamask') {
      if (isIOS) {
        url = 'https://apps.apple.com/app/metamask/id1438144202'
      } else if (isAndroid) {
        url = 'https://play.google.com/store/apps/details?id=io.metamask'
      } else {
        url = 'https://metamask.io/download/'
      }
    } else if (walletType === 'trust') {
      if (isIOS) {
        url = 'https://apps.apple.com/app/trust-crypto-bitcoin-wallet/id1288339409'
      } else if (isAndroid) {
        url = 'https://play.google.com/store/apps/details?id=com.wallet.crypto.trustapp'
      } else {
        url = 'https://trustwallet.com/download'
      }
    } else if (walletType === 'coinbase') {
      if (isIOS) {
        url = 'https://apps.apple.com/app/coinbase-wallet/id1278383455'
      } else if (isAndroid) {
        url = 'https://play.google.com/store/apps/details?id=org.toshi'
      } else {
        url = 'https://www.coinbase.com/wallet'
      }
    }
    
    if (url) {
      console.log('فتح الرابط:', url)
      try {
        window.open(url, '_blank', 'noopener,noreferrer')
      } catch (error) {
        console.error('فشل في فتح الرابط:', error)
        // طريقة بديلة
        const link = document.createElement('a')
        link.href = url
        link.target = '_blank'
        link.rel = 'noopener noreferrer'
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
      }
    }
  }

  // إعادة فحص المحفظة
  const recheckWallet = () => {
    setWalletStatus('checking')
    setTimeout(() => {
      checkWalletAvailability()
    }, 1000)
  }

  // الربط اليدوي للمحفظة
  const connectManually = () => {
    setError('')
    
    if (!manualAddress) {
      setError('يرجى إدخال عنوان المحفظة')
      return
    }

    // التحقق من صحة العنوان (يجب أن يبدأ بـ 0x ويكون 42 حرف)
    if (!manualAddress.startsWith('0x') || manualAddress.length !== 42) {
      setError('عنوان المحفظة غير صحيح. يجب أن يبدأ بـ 0x ويكون 42 حرف')
      return
    }

    // التحقق من أن العنوان يحتوي على أحرف صحيحة فقط
    const validHex = /^0x[a-fA-F0-9]{40}$/.test(manualAddress)
    if (!validHex) {
      setError('عنوان المحفظة يحتوي على أحرف غير صحيحة')
      return
    }

    console.log('ربط يدوي بالعنوان:', manualAddress)
    
    setUserAddress(manualAddress)
    setWalletConnected(true)
    setSuccess('تم ربط المحفظة يدوياً بنجاح! 🎉')
    setShowManualConnect(false)
    setManualAddress('')
    
    // تحديث بيانات اللعبة
    updateGameData(manualAddress)
  }

  // إظهار/إخفاء الربط اليدوي
  const toggleManualConnect = () => {
    setShowManualConnect(!showManualConnect)
    setError('')
    setManualAddress('')
  }

  // محتوى الأقسام
  const renderTabContent = () => {
    switch (activeTab) {
      case 'tutorial':
        return (
          <div className="space-y-6">
            <Card className="bg-green-50 border-green-200">
              <CardHeader>
                <CardTitle className="text-green-800">مرحباً بك في لعبة العملات الرقمية!</CardTitle>
                <CardDescription className="text-green-600">
                  تعلم البلوك تشين واكسب عملات حقيقية
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <h4 className="font-semibold text-green-700">كيفية اللعب:</h4>
                  <ul className="space-y-2 text-sm text-green-600">
                    <li>• اربط محفظة MetaMask للبدء</li>
                    <li>• عدّن العملات كل دقيقة</li>
                    <li>• خزّن العملات لكسب مكافآت 12.5% سنوياً</li>
                    <li>• تعلم من المحتوى التعليمي لكسب خبرة</li>
                    <li>• ارتق في المستويات لزيادة المكافآت</li>
                  </ul>
                </div>
                
                <Alert className="border-orange-200 bg-orange-50">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription className="text-orange-700">
                    <strong>تحذير:</strong> هذا التطبيق يتعامل مع عملات مشفرة حقيقية على شبكة Polygon. 
                    تأكد من فهم المخاطر قبل المتابعة.
                  </AlertDescription>
                </Alert>

                {/* حالة المحفظة */}
                <Card className="bg-blue-50 border-blue-200">
                  <CardHeader>
                    <CardTitle className="text-blue-800 text-sm">حالة المحفظة</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {walletStatus === 'checking' && (
                      <div className="flex items-center gap-2 text-blue-600">
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>فحص توفر المحفظة...</span>
                      </div>
                    )}
                    
                    {walletStatus === 'unavailable' && (
                      <div className="space-y-4">
                        <div className="flex items-center gap-2 text-red-600">
                          <AlertTriangle className="w-4 h-4" />
                          <span>لا توجد محفظة مثبتة</span>
                        </div>
                        
                        <div className="text-sm text-gray-600">
                          <p className="mb-3">اختر محفظة رقمية للتحميل:</p>
                        </div>

                        <div className="grid grid-cols-1 gap-3">
                          <Button 
                            onClick={() => openWalletDownload('metamask')}
                            className="w-full bg-orange-600 hover:bg-orange-700 justify-start"
                          >
                            <Download className="w-4 h-4 ml-2" />
                            MetaMask (موصى به)
                          </Button>
                          
                          <Button 
                            onClick={() => openWalletDownload('trust')}
                            className="w-full bg-blue-600 hover:bg-blue-700 justify-start"
                          >
                            <Download className="w-4 h-4 ml-2" />
                            Trust Wallet
                          </Button>
                          
                          <Button 
                            onClick={() => openWalletDownload('coinbase')}
                            className="w-full bg-indigo-600 hover:bg-indigo-700 justify-start"
                          >
                            <Download className="w-4 h-4 ml-2" />
                            Coinbase Wallet
                          </Button>
                        </div>

                        <div className="pt-3 border-t">
                          <Button 
                            onClick={recheckWallet}
                            variant="outline"
                            className="w-full"
                          >
                            <RefreshCw className="w-4 h-4 ml-2" />
                            إعادة فحص المحفظة
                          </Button>
                        </div>

                        <div className="pt-3 border-t">
                          <Button 
                            onClick={toggleManualConnect}
                            variant="outline"
                            className="w-full"
                          >
                            <Wallet className="w-4 h-4 ml-2" />
                            ربط يدوي للمحفظة
                          </Button>
                        </div>
                      </div>
                    )}
                    
                    {(walletStatus === 'metamask' || walletStatus === 'ethereum') && !walletConnected && (
                      <div className="space-y-4">
                        <div className="flex items-center gap-2 text-green-600">
                          <CheckCircle className="w-4 h-4" />
                          <span>محفظة متوفرة - جاهز للربط</span>
                        </div>
                        
                        <Button 
                          onClick={connectWallet}
                          disabled={isLoading}
                          className="w-full bg-green-600 hover:bg-green-700"
                        >
                          {isLoading ? (
                            <RefreshCw className="w-4 h-4 ml-2 animate-spin" />
                          ) : (
                            <Wallet className="w-4 h-4 ml-2" />
                          )}
                          {isLoading ? 'جاري الربط...' : 'ربط المحفظة'}
                        </Button>

                        <div className="pt-3 border-t">
                          <Button 
                            onClick={toggleManualConnect}
                            variant="outline"
                            className="w-full"
                          >
                            <Wallet className="w-4 h-4 ml-2" />
                            ربط يدوي للمحفظة
                          </Button>
                        </div>
                      </div>
                    )}
                    
                    {walletConnected && (
                      <div className="space-y-4">
                        <div className="flex items-center gap-2 text-green-600">
                          <CheckCircle className="w-4 h-4" />
                          <span>محفظة مربوطة بنجاح</span>
                        </div>
                        
                        <div className="text-xs text-gray-600 bg-gray-50 p-2 rounded">
                          <strong>العنوان:</strong><br />
                          {userAddress}
                        </div>
                        
                        <Button 
                          onClick={disconnectWallet}
                          variant="outline"
                          className="w-full"
                        >
                          قطع الاتصال
                        </Button>
                      </div>
                    )}

                    {/* واجهة الربط اليدوي */}
                    {showManualConnect && (
                      <div className="mt-4 p-4 border rounded-lg bg-gray-50">
                        <h4 className="font-semibold mb-3">ربط يدوي للمحفظة</h4>
                        <div className="space-y-3">
                          <div>
                            <Label htmlFor="manual-address">عنوان المحفظة</Label>
                            <input
                              id="manual-address"
                              type="text"
                              value={manualAddress}
                              onChange={(e) => setManualAddress(e.target.value)}
                              placeholder="0x..."
                              className="w-full mt-1 p-2 border rounded text-sm"
                            />
                          </div>
                          <div className="flex gap-2">
                            <Button 
                              onClick={connectManually}
                              className="flex-1"
                              size="sm"
                            >
                              ربط
                            </Button>
                            <Button 
                              onClick={toggleManualConnect}
                              variant="outline"
                              className="flex-1"
                              size="sm"
                            >
                              إلغاء
                            </Button>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </div>
        )

      case 'wallet':
        return (
          <div className="space-y-6">
            <Card className="bg-blue-50 border-blue-200">
              <CardHeader>
                <CardTitle className="text-blue-800">محفظتك الرقمية</CardTitle>
                <CardDescription className="text-blue-600">
                  إدارة عملاتك ومعاملاتك
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {walletConnected ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-white p-4 rounded-lg border">
                        <div className="text-2xl font-bold text-blue-600">{gameData.balance}</div>
                        <div className="text-sm text-gray-600">الرصيد الحالي</div>
                      </div>
                      <div className="bg-white p-4 rounded-lg border">
                        <div className="text-2xl font-bold text-purple-600">{gameData.stakedAmount}</div>
                        <div className="text-sm text-gray-600">مخزن</div>
                      </div>
                    </div>
                    
                    <div className="bg-white p-3 rounded-lg border">
                      <div className="text-xs text-gray-500 mb-1">المفتاح العام</div>
                      <div className="text-sm font-mono bg-gray-100 p-2 rounded break-all">
                        {gameData.publicKey}
                      </div>
                    </div>
                    
                    <div className="bg-white p-3 rounded-lg border">
                      <div className="text-xs text-gray-500 mb-1">المفتاح الخاص (محاكاة)</div>
                      <div className="text-sm font-mono bg-gray-100 p-2 rounded break-all">
                        {gameData.privateKey}
                      </div>
                    </div>
                    
                    <Alert className="border-yellow-200 bg-yellow-50">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription className="text-yellow-700">
                        <strong>تنبيه:</strong> لا تشارك مفتاحك الخاص مع أي شخص!
                      </AlertDescription>
                    </Alert>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Wallet className="w-16 h-16 mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-600">يرجى ربط المحفظة أولاً</p>
                    <Button 
                      onClick={connectWallet}
                      disabled={isLoading}
                      className="mt-4"
                    >
                      ربط المحفظة
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )

      case 'earning':
        return (
          <div className="space-y-6">
            <Card className="bg-yellow-50 border-yellow-200">
              <CardHeader>
                <CardTitle className="text-yellow-800">مركز الكسب</CardTitle>
                <CardDescription className="text-yellow-600">
                  اكسب العملات من خلال أنشطة مختلفة
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div className="bg-white p-4 rounded-lg border">
                    <h4 className="font-semibold text-yellow-700 mb-2">التعدين اليومي</h4>
                    <p className="text-sm text-gray-600 mb-3">عدّن عملات جديدة كل دقيقة</p>
                    <Button 
                      onClick={mineCoins}
                      disabled={isLoading || !walletConnected}
                      className="w-full bg-yellow-600 hover:bg-yellow-700"
                    >
                      {isLoading ? 'جاري التعدين...' : 'بدء التعدين'}
                    </Button>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg border">
                    <h4 className="font-semibold text-yellow-700 mb-2">المهام اليومية</h4>
                    <p className="text-sm text-gray-600 mb-3">أكمل المهام لكسب مكافآت إضافية</p>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center text-sm">
                        <span>تسجيل الدخول اليومي</span>
                        <Badge variant="secondary">مكتمل</Badge>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span>تعدين 10 عملات</span>
                        <Badge variant="outline">قيد التقدم</Badge>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span>مشاركة اللعبة</span>
                        <Badge variant="outline">غير مكتمل</Badge>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white p-4 rounded-lg border">
                  <h4 className="font-semibold text-yellow-700 mb-2">إحصائيات الكسب</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-gray-600">إجمالي العملات المعدنة</div>
                      <div className="font-bold text-yellow-600">{gameData.minedCoins}</div>
                    </div>
                    <div>
                      <div className="text-gray-600">المكافآت المعلقة</div>
                      <div className="font-bold text-green-600">{gameData.pendingRewards}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )

      case 'staking':
        return (
          <div className="space-y-6">
            <Card className="bg-purple-50 border-purple-200">
              <CardHeader>
                <CardTitle className="text-purple-800">تخزين العملات</CardTitle>
                <CardDescription className="text-purple-600">
                  خزّن عملاتك واكسب مكافآت 12.5% سنوياً
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {walletConnected ? (
                  <div className="space-y-4">
                    <div className="bg-white p-4 rounded-lg border">
                      <h4 className="font-semibold text-purple-700 mb-3">معلومات التخزين</h4>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <div className="text-gray-600">المبلغ المخزن</div>
                          <div className="font-bold text-purple-600">{gameData.stakedAmount}</div>
                        </div>
                        <div>
                          <div className="text-gray-600">المكافآت المعلقة</div>
                          <div className="font-bold text-green-600">{gameData.pendingRewards}</div>
                        </div>
                      </div>
                      
                      <div className="mt-4">
                        <Button 
                          onClick={claimRewards}
                          disabled={isLoading || gameData.pendingRewards === 0}
                          className="w-full bg-green-600 hover:bg-green-700"
                        >
                          {isLoading ? 'جاري السحب...' : 'سحب المكافآت'}
                        </Button>
                      </div>
                    </div>
                    
                    <div className="bg-white p-4 rounded-lg border">
                      <h4 className="font-semibold text-purple-700 mb-3">تخزين جديد</h4>
                      <div className="space-y-3">
                        <div className="flex gap-2">
                          <Button 
                            onClick={() => stakeCoins(10)}
                            disabled={isLoading || gameData.balance < 10}
                            className="flex-1 bg-purple-600 hover:bg-purple-700"
                            size="sm"
                          >
                            خزّن 10
                          </Button>
                          <Button 
                            onClick={() => stakeCoins(50)}
                            disabled={isLoading || gameData.balance < 50}
                            className="flex-1 bg-purple-600 hover:bg-purple-700"
                            size="sm"
                          >
                            خزّن 50
                          </Button>
                          <Button 
                            onClick={() => stakeCoins(100)}
                            disabled={isLoading || gameData.balance < 100}
                            className="flex-1 bg-purple-600 hover:bg-purple-700"
                            size="sm"
                          >
                            خزّن 100
                          </Button>
                        </div>
                        
                        <div className="text-xs text-gray-500">
                          الرصيد المتاح: {gameData.balance} عملة
                        </div>
                      </div>
                    </div>
                    
                    <Alert className="border-blue-200 bg-blue-50">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription className="text-blue-700">
                        <strong>معلومة:</strong> التخزين يحقق عائد 12.5% سنوياً. 
                        المكافآت تُحسب يومياً ويمكن سحبها في أي وقت.
                      </AlertDescription>
                    </Alert>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Lock className="w-16 h-16 mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-600">يرجى ربط المحفظة أولاً</p>
                    <Button 
                      onClick={connectWallet}
                      disabled={isLoading}
                      className="mt-4"
                    >
                      ربط المحفظة
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )

      case 'network':
        return (
          <div className="space-y-6">
            <Card className="bg-teal-50 border-teal-200">
              <CardHeader>
                <CardTitle className="text-teal-800">معلومات الشبكة</CardTitle>
                <CardDescription className="text-teal-600">
                  تفاصيل شبكة Polygon والاتصال
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div className="bg-white p-4 rounded-lg border">
                    <h4 className="font-semibold text-teal-700 mb-3">معلومات الشبكة</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">اسم الشبكة</span>
                        <span className="font-medium">Polygon Mainnet</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Chain ID</span>
                        <span className="font-medium">137</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">العملة</span>
                        <span className="font-medium">MATIC</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">RPC URL</span>
                        <span className="font-medium text-xs">https://polygon-rpc.com/</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg border">
                    <h4 className="font-semibold text-teal-700 mb-3">حالة الاتصال</h4>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${walletConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
                        <span className="text-sm">
                          {walletConnected ? 'متصل بالشبكة' : 'غير متصل'}
                        </span>
                      </div>
                      {walletConnected && (
                        <div className="text-xs text-gray-500 bg-gray-50 p-2 rounded">
                          العنوان: {userAddress}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg border">
                    <h4 className="font-semibold text-teal-700 mb-3">روابط مفيدة</h4>
                    <div className="space-y-2">
                      <a 
                        href="https://polygonscan.com/" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 text-sm text-teal-600 hover:text-teal-800"
                      >
                        <ExternalLink className="w-4 h-4" />
                        Polygon Explorer
                      </a>
                      <a 
                        href="https://wallet.polygon.technology/" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 text-sm text-teal-600 hover:text-teal-800"
                      >
                        <ExternalLink className="w-4 h-4" />
                        Polygon Wallet
                      </a>
                      <a 
                        href="https://polygon.technology/" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 text-sm text-teal-600 hover:text-teal-800"
                      >
                        <ExternalLink className="w-4 h-4" />
                        موقع Polygon الرسمي
                      </a>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )

      case 'mining':
        return (
          <div className="space-y-6">
            <Card className="bg-red-50 border-red-200">
              <CardHeader>
                <CardTitle className="text-red-800">مركز التعدين</CardTitle>
                <CardDescription className="text-red-600">
                  عدّن العملات واكسب مكافآت
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {walletConnected ? (
                  <div className="space-y-4">
                    <div className="bg-white p-4 rounded-lg border">
                      <h4 className="font-semibold text-red-700 mb-3">حالة التعدين</h4>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <div className="text-gray-600">إجمالي العملات المعدنة</div>
                          <div className="font-bold text-red-600">{gameData.minedCoins}</div>
                        </div>
                        <div>
                          <div className="text-gray-600">حالة التعدين</div>
                          <div className={`font-bold ${gameData.canMine ? 'text-green-600' : 'text-orange-600'}`}>
                            {gameData.canMine ? 'جاهز' : 'انتظار'}
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-white p-4 rounded-lg border">
                      <h4 className="font-semibold text-red-700 mb-3">تعدين سريع</h4>
                      <Button 
                        onClick={mineCoins}
                        disabled={isLoading || !gameData.canMine}
                        className="w-full bg-red-600 hover:bg-red-700"
                      >
                        {isLoading ? (
                          <RefreshCw className="w-4 h-4 ml-2 animate-spin" />
                        ) : (
                          <Pickaxe className="w-4 h-4 ml-2" />
                        )}
                        {isLoading ? 'جاري التعدين...' : 'بدء التعدين'}
                      </Button>
                    </div>
                    
                    <div className="bg-white p-4 rounded-lg border">
                      <h4 className="font-semibold text-red-700 mb-3">إحصائيات التعدين</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">المستوى الحالي</span>
                          <span className="font-medium">المستوى {gameData.level}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">نقاط الخبرة</span>
                          <span className="font-medium">{gameData.experience}</span>
                        </div>
                        <div className="mt-3">
                          <div className="text-gray-600 mb-1">تقدم المستوى</div>
                          <Progress value={(gameData.experience % 1000) / 10} className="h-2" />
                        </div>
                      </div>
                    </div>
                    
                    <Alert className="border-orange-200 bg-orange-50">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription className="text-orange-700">
                        <strong>نصيحة:</strong> كلما ارتفع مستواك، زادت مكافآت التعدين!
                      </AlertDescription>
                    </Alert>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Pickaxe className="w-16 h-16 mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-600">يرجى ربط المحفظة أولاً</p>
                    <Button 
                      onClick={connectWallet}
                      disabled={isLoading}
                      className="mt-4"
                    >
                      ربط المحفظة
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )

      case 'blockchain':
        return (
          <div className="space-y-6">
            <Card className="bg-gray-50 border-gray-200">
              <CardHeader>
                <CardTitle className="text-gray-800">تعلم البلوك تشين</CardTitle>
                <CardDescription className="text-gray-600">
                  محتوى تعليمي شامل عن تقنية البلوك تشين
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div className="bg-white p-4 rounded-lg border">
                    <h4 className="font-semibold text-gray-700 mb-3">ما هو البلوك تشين؟</h4>
                    <p className="text-sm text-gray-600 mb-3">
                      البلوك تشين هو تقنية دفتر حسابات موزع يحتفظ بسجل دائم ومقاوم للتلاعب 
                      من المعاملات عبر شبكة من أجهزة الكمبيوتر.
                    </p>
                    <div className="space-y-2 text-sm">
                      <div>• <strong>اللامركزية:</strong> لا توجد سلطة مركزية واحدة</div>
                      <div>• <strong>الشفافية:</strong> جميع المعاملات مرئية للجميع</div>
                      <div>• <strong>الأمان:</strong> مقاوم للتلاعب والاختراق</div>
                      <div>• <strong>عدم القابلية للتغيير:</strong> لا يمكن تعديل البيانات المسجلة</div>
                    </div>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg border">
                    <h4 className="font-semibold text-gray-700 mb-3">العملات المشفرة</h4>
                    <p className="text-sm text-gray-600 mb-3">
                      العملات المشفرة هي أصول رقمية تستخدم التشفير لتأمين المعاملات 
                      والتحكم في إنشاء وحدات جديدة.
                    </p>
                    <div className="space-y-2 text-sm">
                      <div>• <strong>Bitcoin:</strong> أول عملة مشفرة في العالم</div>
                      <div>• <strong>Ethereum:</strong> منصة للعقود الذكية</div>
                      <div>• <strong>Polygon:</strong> حل توسيع لـ Ethereum</div>
                      <div>• <strong>MATIC:</strong> العملة الأصلية لشبكة Polygon</div>
                    </div>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg border">
                    <h4 className="font-semibold text-gray-700 mb-3">المحافظ الرقمية</h4>
                    <p className="text-sm text-gray-600 mb-3">
                      المحافظ الرقمية هي تطبيقات تسمح لك بتخزين وإدارة عملاتك المشفرة بأمان.
                    </p>
                    <div className="space-y-2 text-sm">
                      <div>• <strong>المفتاح العام:</strong> عنوانك الذي يمكن مشاركته</div>
                      <div>• <strong>المفتاح الخاص:</strong> كلمة المرور السرية لمحفظتك</div>
                      <div>• <strong>العبارة الاحتياطية:</strong> 12-24 كلمة لاستعادة المحفظة</div>
                      <div>• <strong>التوقيع الرقمي:</strong> إثبات ملكية المعاملة</div>
                    </div>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg border">
                    <h4 className="font-semibold text-gray-700 mb-3">نصائح الأمان</h4>
                    <div className="space-y-2 text-sm text-red-600">
                      <div>⚠️ لا تشارك مفتاحك الخاص مع أي شخص</div>
                      <div>⚠️ احتفظ بنسخة احتياطية من عبارة الاستعادة</div>
                      <div>⚠️ تحقق دائماً من عناوين المعاملات</div>
                      <div>⚠️ استخدم شبكات آمنة فقط</div>
                      <div>⚠️ احذر من المواقع المزيفة والاحتيال</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )

      default:
        return <div>المحتوى غير متوفر</div>
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="max-width-md mx-auto">
        {/* Header */}
        <div className="bg-white rounded-t-2xl shadow-lg p-6 border-b">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-800 mb-2">
              🚀 لعبة العملات الرقمية
            </h1>
            <p className="text-gray-600 text-sm">
              تعلم البلوك تشين واكسب عملات حقيقية على شبكة Polygon
            </p>
            
            {/* حالة الاتصال */}
            <div className="mt-4 flex items-center justify-center gap-2">
              <div className={`w-3 h-3 rounded-full ${walletConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
              <span className="text-sm text-gray-600">
                {walletConnected ? `متصل: ${userAddress.slice(0, 6)}...${userAddress.slice(-4)}` : 'غير متصل'}
              </span>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white shadow-lg">
          <div className="grid grid-cols-4 gap-1 p-1">
            {tabs.slice(0, 4).map((tab, index) => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`
                    ${tab.color} text-white p-3 text-xs font-semibold rounded-lg transition-all duration-200
                    ${activeTab === tab.id ? 'scale-105 shadow-lg' : 'hover:scale-102'}
                  `}
                >
                  <Icon className="w-4 h-4 mx-auto mb-1" />
                  {tab.name}
                </button>
              )
            })}
          </div>
          <div className="grid grid-cols-3 gap-1 p-1">
            {tabs.slice(4).map((tab, index) => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`
                    ${tab.color} text-white p-3 text-xs font-semibold rounded-lg transition-all duration-200
                    ${activeTab === tab.id ? 'scale-105 shadow-lg' : 'hover:scale-102'}
                  `}
                >
                  <Icon className="w-4 h-4 mx-auto mb-1" />
                  {tab.name}
                </button>
              )
            })}
          </div>
        </div>

        {/* Content */}
        <div className="bg-white rounded-b-2xl shadow-lg p-6">
          {/* رسائل التنبيه */}
          {error && (
            <Alert className="mb-4 border-red-200 bg-red-50">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription className="text-red-700">
                {error}
              </AlertDescription>
            </Alert>
          )}
          
          {success && (
            <Alert className="mb-4 border-green-200 bg-green-50">
              <CheckCircle className="h-4 w-4" />
              <AlertDescription className="text-green-700">
                {success}
              </AlertDescription>
            </Alert>
          )}

          {/* محتوى التبويب */}
          {renderTabContent()}
        </div>

        {/* Footer */}
        <div className="text-center mt-6 text-xs text-gray-500">
          <p>⚠️ تحذير: هذا التطبيق يتعامل مع عملات مشفرة حقيقية</p>
          <p>تأكد من فهم المخاطر قبل المتابعة</p>
          <p className="mt-2">
            Ethers.js Status: {ethers ? '✅ متوفر' : '❌ غير متوفر'}
          </p>
        </div>
      </div>
    </div>
  )
}

export default App
