import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { 
  Wallet, 
  Coins, 
  TrendingUp, 
  Lock, 
  Globe, 
  Pickaxe, 
  BookOpen,
  AlertTriangle,
  CheckCircle,
  ExternalLink,
  RefreshCw,
  Download
} from 'lucide-react'
import './App.css'

function App() {
  // حالة الاتصال بالمحفظة
  const [walletConnected, setWalletConnected] = useState(false)
  const [userAddress, setUserAddress] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [walletStatus, setWalletStatus] = useState('checking')
  
  // حالة اللعبة
  const [gameData, setGameData] = useState({
    balance: 0,
    level: 1,
    experience: 0,
    minedCoins: 0,
    stakedAmount: 0,
    pendingRewards: 0,
    canMine: true,
    publicKey: '0x742d35Cc6634C0532925a3b8D0F4E7C87',
    privateKey: 'abc123def456ghi789jkl012mno345pqr678stu901vwx234yz'
  })
  
  const [activeTab, setActiveTab] = useState('tutorial')
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [manualAddress, setManualAddress] = useState('')
  const [showManualConnect, setShowManualConnect] = useState(false)

  // الأقسام مع الألوان
  const tabs = [
    { id: 'tutorial', name: 'الدليل التعليمي', color: 'bg-green-500', icon: BookOpen },
    { id: 'wallet', name: 'المحفظة', color: 'bg-blue-500', icon: Wallet },
    { id: 'earning', name: 'الكسب', color: 'bg-yellow-500', icon: Coins },
    { id: 'staking', name: 'التخزين', color: 'bg-purple-500', icon: Lock },
    { id: 'network', name: 'الشبكة', color: 'bg-teal-500', icon: Globe },
    { id: 'mining', name: 'التعدين', color: 'bg-red-500', icon: Pickaxe },
    { id: 'blockchain', name: 'البلوك تشين', color: 'bg-gray-500', icon: TrendingUp }
  ]

  // فحص توفر المحفظة
  useEffect(() => {
    checkWalletAvailability()
  }, [])

  const checkWalletAvailability = () => {
    // فحص متعدد للمحافظ المختلفة
    const hasMetaMask = typeof window.ethereum !== 'undefined' && window.ethereum.isMetaMask
    const hasEthereum = typeof window.ethereum !== 'undefined'
    const hasWeb3 = typeof window.web3 !== 'undefined'
    
    console.log('فحص المحافظ:', {
      hasMetaMask,
      hasEthereum,
      hasWeb3,
      userAgent: navigator.userAgent
    })

    if (hasMetaMask) {
      setWalletStatus('metamask')
      console.log('MetaMask متوفر')
    } else if (hasEthereum) {
      setWalletStatus('ethereum')
      console.log('محفظة Ethereum متوفرة')
    } else {
      setWalletStatus('unavailable')
      console.log('لا توجد محفظة متوفرة')
    }
  }

  // ربط المحفظة المبسط
  const connectWallet = async () => {
    setIsLoading(true)
    setError('')
    setSuccess('')

    try {
      // فحص توفر المحفظة
      if (!window.ethereum) {
        throw new Error('لا توجد محفظة مثبتة')
      }

      console.log('بدء الاتصال بالمحفظة...')

      // طريقة بسيطة للاتصال
      const accounts = await window.ethereum.request({
        method: 'eth_requestAccounts'
      })

      if (accounts && accounts.length > 0) {
        const address = accounts[0]
        console.log('تم الاتصال بالعنوان:', address)
        
        setUserAddress(address)
        setWalletConnected(true)
        setSuccess('تم ربط المحفظة بنجاح! 🎉')
        
        // تحديث بيانات اللعبة
        updateGameData(address)
      } else {
        throw new Error('لم يتم العثور على حسابات')
      }

    } catch (error) {
      console.error('خطأ في الاتصال:', error)
      
      if (error.code === 4001) {
        setError('تم إلغاء الاتصال من قبل المستخدم')
      } else if (error.code === -32002) {
        setError('يوجد طلب اتصال معلق. يرجى فحص المحفظة.')
      } else {
        setError(`خطأ في الاتصال: ${error.message}`)
      }
    }

    setIsLoading(false)
  }

  // قطع الاتصال
  const disconnectWallet = () => {
    setWalletConnected(false)
    setUserAddress('')
    setSuccess('تم قطع الاتصال بالمحفظة')
  }

  // تحديث بيانات اللعبة
  const updateGameData = (address) => {
    // محاكاة البيانات
    setGameData(prev => ({
      ...prev,
      balance: Math.floor(Math.random() * 1000) + 100,
      level: Math.floor(Math.random() * 10) + 1,
      experience: Math.floor(Math.random() * 5000),
      minedCoins: Math.floor(Math.random() * 500),
      stakedAmount: Math.floor(Math.random() * 200),
      pendingRewards: Math.floor(Math.random() * 50) + 10,
      publicKey: address
    }))
  }

  // تعدين العملات
  const mineCoins = async () => {
    if (!walletConnected) {
      setError('يرجى ربط المحفظة أولاً')
      return
    }

    setIsLoading(true)
    setError('')

    try {
      // محاكاة التعدين
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      const reward = Math.floor(Math.random() * 10) + 1
      setGameData(prev => ({
        ...prev,
        balance: prev.balance + reward,
        minedCoins: prev.minedCoins + reward,
        experience: prev.experience + reward * 10
      }))
      
      setSuccess(`تم تعدين ${reward} عملة بنجاح! 🎉`)
    } catch (error) {
      setError('فشل في التعدين')
    }

    setIsLoading(false)
  }

  // تخزين العملات
  const stakeCoins = async (amount) => {
    if (!walletConnected) {
      setError('يرجى ربط المحفظة أولاً')
      return
    }

    if (gameData.balance < amount) {
      setError('رصيد غير كافي للتخزين')
      return
    }

    setIsLoading(true)
    setError('')

    try {
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      setGameData(prev => ({
        ...prev,
        balance: prev.balance - amount,
        stakedAmount: prev.stakedAmount + amount
      }))
      
      setSuccess(`تم تخزين ${amount} عملة بنجاح! 💎`)
    } catch (error) {
      setError('فشل في التخزين')
    }

    setIsLoading(false)
  }

  // سحب المكافآت
  const claimRewards = async () => {
    if (!walletConnected) {
      setError('يرجى ربط المحفظة أولاً')
      return
    }

    if (gameData.pendingRewards === 0) {
      setError('لا توجد مكافآت للسحب')
      return
    }

    setIsLoading(true)
    setError('')

    try {
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      const rewards = gameData.pendingRewards
      setGameData(prev => ({
        ...prev,
        balance: prev.balance + rewards,
        pendingRewards: 0
      }))
      
      setSuccess(`تم سحب ${rewards} عملة كمكافآت! 💰`)
    } catch (error) {
      setError('فشل في سحب المكافآت')
    }

    setIsLoading(false)
  }

  // فتح رابط تحميل المحفظة
  const openWalletDownload = (walletType = 'metamask') => {
    // اكتشاف نوع الجهاز
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent)
    const isAndroid = /Android/i.test(navigator.userAgent)
    
    console.log('فتح رابط التحميل:', { walletType, isMobile, isIOS, isAndroid })
    
    let url = ''
    
    if (walletType === 'metamask') {
      if (isIOS) {
        url = 'https://apps.apple.com/app/metamask/id1438144202'
      } else if (isAndroid) {
        url = 'https://play.google.com/store/apps/details?id=io.metamask'
      } else {
        url = 'https://metamask.io/download/'
      }
    } else if (walletType === 'trust') {
      if (isIOS) {
        url = 'https://apps.apple.com/app/trust-crypto-bitcoin-wallet/id1288339409'
      } else if (isAndroid) {
        url = 'https://play.google.com/store/apps/details?id=com.wallet.crypto.trustapp'
      } else {
        url = 'https://trustwallet.com/download'
      }
    } else if (walletType === 'coinbase') {
      if (isIOS) {
        url = 'https://apps.apple.com/app/coinbase-wallet/id1278383455'
      } else if (isAndroid) {
        url = 'https://play.google.com/store/apps/details?id=org.toshi'
      } else {
        url = 'https://www.coinbase.com/wallet'
      }
    }
    
    if (url) {
      console.log('فتح الرابط:', url)
      // محاولة فتح الرابط بطرق متعددة
      try {
        window.open(url, '_blank', 'noopener,noreferrer')
      } catch (error) {
        console.error('فشل في فتح الرابط:', error)
        // طريقة بديلة
        const link = document.createElement('a')
        link.href = url
        link.target = '_blank'
        link.rel = 'noopener noreferrer'
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
      }
    }
  }

  // إعادة فحص المحفظة
  const recheckWallet = () => {
    setWalletStatus('checking')
    setTimeout(() => {
      checkWalletAvailability()
    }, 1000)
  }

  // الربط اليدوي للمحفظة
  const connectManually = () => {
    setError('')
    
    if (!manualAddress) {
      setError('يرجى إدخال عنوان المحفظة')
      return
    }

    // التحقق من صحة العنوان (يجب أن يبدأ بـ 0x ويكون 42 حرف)
    if (!manualAddress.startsWith('0x') || manualAddress.length !== 42) {
      setError('عنوان المحفظة غير صحيح. يجب أن يبدأ بـ 0x ويكون 42 حرف')
      return
    }

    // التحقق من أن العنوان يحتوي على أحرف صحيحة فقط
    const validHex = /^0x[a-fA-F0-9]{40}$/.test(manualAddress)
    if (!validHex) {
      setError('عنوان المحفظة يحتوي على أحرف غير صحيحة')
      return
    }

    console.log('ربط يدوي بالعنوان:', manualAddress)
    
    setUserAddress(manualAddress)
    setWalletConnected(true)
    setSuccess('تم ربط المحفظة يدوياً بنجاح! 🎉')
    setShowManualConnect(false)
    setManualAddress('')
    
    // تحديث بيانات اللعبة
    updateGameData(manualAddress)
  }

  // إظهار/إخفاء الربط اليدوي
  const toggleManualConnect = () => {
    setShowManualConnect(!showManualConnect)
    setError('')
    setManualAddress('')
  }

  // محتوى الأقسام
  const renderTabContent = () => {
    switch (activeTab) {
      case 'tutorial':
        return (
          <div className="space-y-6">
            <Card className="bg-green-50 border-green-200">
              <CardHeader>
                <CardTitle className="text-green-800">مرحباً بك في لعبة العملات الرقمية!</CardTitle>
                <CardDescription className="text-green-600">
                  تعلم البلوك تشين واكسب عملات حقيقية
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <h4 className="font-semibold text-green-700">كيفية اللعب:</h4>
                  <ul className="space-y-2 text-sm text-green-600">
                    <li>• اربط محفظة MetaMask للبدء</li>
                    <li>• عدّن العملات كل دقيقة</li>
                    <li>• خزّن العملات لكسب مكافآت 12.5% سنوياً</li>
                    <li>• تعلم من المحتوى التعليمي لكسب خبرة</li>
                    <li>• ارتق في المستويات لزيادة المكافآت</li>
                  </ul>
                </div>
                
                <Alert className="border-orange-200 bg-orange-50">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription className="text-orange-700">
                    <strong>تحذير:</strong> هذا التطبيق يتعامل مع عملات مشفرة حقيقية على شبكة Polygon. 
                    تأكد من فهم المخاطر قبل المتابعة.
                  </AlertDescription>
                </Alert>

                {/* حالة المحفظة */}
                <Card className="bg-blue-50 border-blue-200">
                  <CardHeader>
                    <CardTitle className="text-blue-800 text-sm">حالة المحفظة</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {walletStatus === 'checking' && (
                      <div className="flex items-center gap-2 text-blue-600">
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>فحص توفر المحفظة...</span>
                      </div>
                    )}
                    
                    {walletStatus === 'unavailable' && (
                      <div className="space-y-4">
                        <div className="flex items-center gap-2 text-red-600">
                          <AlertTriangle className="w-4 h-4" />
                          <span>لا توجد محفظة مثبتة</span>
                        </div>
                        
                        <div className="text-sm text-gray-600">
                          <p className="mb-3">اختر محفظة رقمية للتحميل:</p>
                        </div>

                        <div className="grid grid-cols-1 gap-3">
                          <Button 
                            onClick={() => openWalletDownload('metamask')}
                            className="w-full bg-orange-600 hover:bg-orange-700 justify-start"
                          >
                            <Download className="w-4 h-4 ml-2" />
                            MetaMask (موصى به)
                          </Button>
                          
                          <Button 
                            onClick={() => openWalletDownload('trust')}
                            className="w-full bg-blue-600 hover:bg-blue-700 justify-start"
                          >
                            <Download className="w-4 h-4 ml-2" />
                            Trust Wallet
                          </Button>
                          
                          <Button 
                            onClick={() => openWalletDownload('coinbase')}
                            className="w-full bg-indigo-600 hover:bg-indigo-700 justify-start"
                          >
                            <Download className="w-4 h-4 ml-2" />
                            Coinbase Wallet
                          </Button>
                        </div>

                        <div className="pt-3 border-t">
                          <Button 
                            onClick={recheckWallet}
                            variant="outline"
                            className="w-full"
                          >
                            <RefreshCw className="w-4 h-4 ml-2" />
                            إعادة فحص المحفظة
                          </Button>
                        </div>

                        <div className="text-xs text-gray-500 text-center">
                          بعد التثبيت، اضغط "إعادة فحص المحفظة"
                        </div>
                      </div>
                    )}
                    
                    {(walletStatus === 'metamask' || walletStatus === 'ethereum') && !walletConnected && (
                      <div className="flex items-center gap-2 text-green-600">
                        <CheckCircle className="w-4 h-4" />
                        <span>محفظة متوفرة - جاهز للاتصال</span>
                      </div>
                    )}
                    
                    {walletConnected && (
                      <div className="flex items-center gap-2 text-green-600">
                        <CheckCircle className="w-4 h-4" />
                        <span>متصل بنجاح</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </div>
        )

      case 'wallet':
        return (
          <div className="space-y-6">
            {/* Real Wallet Connection */}
            {!walletConnected && (
              <Card className="bg-blue-50 border-blue-200">
                <CardHeader>
                  <CardTitle className="text-blue-800">ربط محفظة حقيقية</CardTitle>
                  <CardDescription className="text-blue-600">
                    اربط محفظة رقمية للتعامل مع العملات المشفرة الحقيقية
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {walletStatus === 'unavailable' && (
                    <Alert className="border-red-200 bg-red-50">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription className="text-red-700">
                        <div className="space-y-2">
                          <p>لا توجد محفظة رقمية مثبتة.</p>
                          <p className="text-sm">يرجى تثبيت إحدى المحافظ التالية:</p>
                          <ul className="text-sm list-disc list-inside">
                            <li>MetaMask (موصى به)</li>
                            <li>Trust Wallet</li>
                            <li>Coinbase Wallet</li>
                          </ul>
                        </div>
                      </AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="space-y-3">
                    {walletStatus === 'unavailable' ? (
                      <Button 
                        onClick={() => openWalletDownload('metamask')}
                        className="w-full bg-orange-600 hover:bg-orange-700"
                      >
                        <Download className="w-4 h-4 ml-2" />
                        تحميل محفظة رقمية
                      </Button>
                    ) : (
                      <Button 
                        onClick={connectWallet} 
                        disabled={isLoading}
                        className="w-full bg-blue-600 hover:bg-blue-700"
                      >
                        <Wallet className="w-4 h-4 ml-2" />
                        {isLoading ? 'جاري الاتصال...' : 'ربط المحفظة تلقائياً'}
                      </Button>
                    )}

                    {/* زر الربط اليدوي */}
                    <Button 
                      onClick={toggleManualConnect}
                      variant="outline"
                      className="w-full"
                    >
                      {showManualConnect ? 'إلغاء الربط اليدوي' : 'ربط يدوي بعنوان المحفظة'}
                    </Button>

                    {/* واجهة الربط اليدوي */}
                    {showManualConnect && (
                      <div className="space-y-3 p-4 bg-gray-50 rounded border">
                        <div>
                          <Label className="text-sm font-medium text-gray-700">
                            عنوان المحفظة (0x...)
                          </Label>
                          <input
                            type="text"
                            value={manualAddress}
                            onChange={(e) => setManualAddress(e.target.value)}
                            placeholder="0x742d35Cc6634C0532925a3b8D0F4E7C87..."
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md text-sm font-mono"
                            dir="ltr"
                          />
                        </div>
                        
                        <div className="text-xs text-gray-500">
                          <p>• يجب أن يبدأ العنوان بـ 0x</p>
                          <p>• يجب أن يكون 42 حرف بالضبط</p>
                          <p>• يمكنك نسخ العنوان من محفظتك</p>
                        </div>

                        {/* عنوان محفوظ مسبقاً */}
                        <div className="bg-blue-50 p-3 rounded border">
                          <p className="text-xs text-blue-600 mb-2">عنوان محفوظ مسبقاً:</p>
                          <Button 
                            onClick={() => setManualAddress('0x77A1b3C01278EEC4B978Bc46727F7bbd30C6798C')}
                            variant="outline"
                            className="w-full text-xs font-mono"
                            dir="ltr"
                          >
                            0x77A1b3C01278EEC4B978Bc46727F7bbd30C6798C
                          </Button>
                        </div>

                        <Button 
                          onClick={connectManually}
                          className="w-full bg-green-600 hover:bg-green-700"
                        >
                          <CheckCircle className="w-4 h-4 ml-2" />
                          ربط المحفظة يدوياً
                        </Button>
                      </div>
                    )}
                  </div>

                  <div className="text-center space-y-2">
                    <p className="text-sm text-gray-600">روابط التحميل:</p>
                    <div className="flex justify-center gap-4 text-sm">
                      <a 
                        href="https://metamask.io/download/" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:text-blue-800 flex items-center gap-1"
                      >
                        MetaMask
                        <ExternalLink className="w-3 h-3" />
                      </a>
                      <a 
                        href="https://trustwallet.com/download" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:text-blue-800 flex items-center gap-1"
                      >
                        Trust Wallet
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {walletConnected && (
              <Card className="bg-green-50 border-green-200">
                <CardHeader>
                  <CardTitle className="text-green-800 flex items-center gap-2">
                    <CheckCircle className="w-5 h-5" />
                    محفظة متصلة
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <p className="text-sm text-green-700">عنوان المحفظة:</p>
                    <p className="font-mono text-sm bg-white p-2 rounded border break-all">
                      {userAddress}
                    </p>
                  </div>
                  
                  <Button 
                    onClick={disconnectWallet}
                    variant="outline"
                    className="w-full"
                  >
                    قطع الاتصال
                  </Button>
                </CardContent>
              </Card>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Mining Info */}
              <Card className="bg-white border-2">
                <CardHeader className="bg-gray-50">
                  <CardTitle className="flex items-center gap-2">
                    <Pickaxe className="w-5 h-5" />
                    معلومات التعدين
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="text-center mb-6">
                    <div className="text-4xl font-bold text-green-600 mb-2">
                      {gameData.balance} عملة
                    </div>
                    <p className="text-gray-600">الرصيد الحالي</p>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span>العملات المعدنة:</span>
                      <span className="font-semibold">{gameData.minedCoins}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>نقاط الخبرة:</span>
                      <span className="font-semibold">{gameData.experience}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Wallet Keys */}
              <Card className="bg-white border-2">
                <CardHeader className="bg-gray-50">
                  <CardTitle className="flex items-center gap-2">
                    <Wallet className="w-5 h-5" />
                    مفاتيح التشفير
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-700">المفتاح العام:</Label>
                    <div className="mt-1 p-3 bg-orange-100 border border-orange-300 rounded text-center font-mono text-sm break-all">
                      {gameData.publicKey}
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-sm font-medium text-gray-700">المفتاح الخاص:</Label>
                    <div className="mt-1 p-3 bg-pink-100 border border-pink-300 rounded text-center font-mono text-sm">
                      {gameData.privateKey}
                    </div>
                  </div>
                  
                  <div className="text-center text-red-500 text-sm mt-4">
                    ⚠️ احتفظ بهذا المفتاح سرياً ⚠️
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )

      case 'mining':
        return (
          <div className="space-y-6">
            <Card className="bg-red-50 border-red-200">
              <CardHeader>
                <CardTitle className="text-red-800 flex items-center gap-2">
                  <Pickaxe className="w-5 h-5" />
                  مركز التعدين
                </CardTitle>
                <CardDescription className="text-red-600">
                  عدّن عملات GTK كل دقيقة
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-red-600 mb-2">
                    المستوى {gameData.level}
                  </div>
                  <Progress value={(gameData.experience % 1000) / 10} className="w-full" />
                  <p className="text-sm text-red-500 mt-2">
                    {gameData.experience % 1000}/1000 خبرة للمستوى التالي
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-white rounded border">
                    <div className="text-2xl font-bold text-green-600">{gameData.balance}</div>
                    <div className="text-sm text-gray-600">الرصيد الحالي</div>
                  </div>
                  <div className="text-center p-4 bg-white rounded border">
                    <div className="text-2xl font-bold text-blue-600">{gameData.minedCoins}</div>
                    <div className="text-sm text-gray-600">إجمالي المعدن</div>
                  </div>
                </div>

                <Button 
                  onClick={mineCoins} 
                  disabled={isLoading || !walletConnected}
                  className="w-full bg-red-600 hover:bg-red-700 text-white py-3"
                >
                  <Pickaxe className="w-4 h-4 ml-2" />
                  {isLoading ? 'جاري التعدين...' : 'تعدين العملات'}
                </Button>

                {!walletConnected && (
                  <p className="text-center text-red-500 text-sm">
                    يرجى ربط المحفظة أولاً للبدء في التعدين
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        )

      case 'staking':
        return (
          <div className="space-y-6">
            <Card className="bg-purple-50 border-purple-200">
              <CardHeader>
                <CardTitle className="text-purple-800 flex items-center gap-2">
                  <Lock className="w-5 h-5" />
                  تخزين العملات
                </CardTitle>
                <CardDescription className="text-purple-600">
                  خزّن عملاتك واكسب 12.5% سنوياً
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-white rounded border">
                    <div className="text-2xl font-bold text-purple-600">{gameData.stakedAmount}</div>
                    <div className="text-sm text-gray-600">المبلغ المخزن</div>
                  </div>
                  <div className="text-center p-4 bg-white rounded border">
                    <div className="text-2xl font-bold text-green-600">{gameData.pendingRewards}</div>
                    <div className="text-sm text-gray-600">المكافآت المتراكمة</div>
                  </div>
                </div>

                <div className="space-y-4">
                  <Button 
                    onClick={() => stakeCoins(10)} 
                    disabled={isLoading || !walletConnected || gameData.balance < 10}
                    className="w-full bg-purple-600 hover:bg-purple-700"
                  >
                    <Lock className="w-4 h-4 ml-2" />
                    تخزين 10 عملات
                  </Button>

                  <Button 
                    onClick={claimRewards} 
                    disabled={isLoading || !walletConnected || gameData.pendingRewards === 0}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    <Coins className="w-4 h-4 ml-2" />
                    سحب المكافآت ({gameData.pendingRewards} عملة)
                  </Button>
                </div>

                <div className="text-center text-sm text-purple-600">
                  <p>العائد السنوي: 12.5%</p>
                  <p>فترة القفل: 7 أيام</p>
                </div>
              </CardContent>
            </Card>
          </div>
        )

      default:
        return (
          <div className="text-center py-12">
            <h3 className="text-xl font-semibold mb-4">قريباً...</h3>
            <p className="text-gray-600">هذا القسم قيد التطوير</p>
          </div>
        )
    }
  }

  return (
    <div className="min-h-screen bg-gray-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-gray-900">
              لعبة العملات الرقمية الحقيقية
            </h1>
            {walletConnected && (
              <Badge className="bg-green-100 text-green-800 border-green-200">
                <CheckCircle className="w-3 h-3 ml-1" />
                متصل: {userAddress.slice(0, 6)}...{userAddress.slice(-4)}
              </Badge>
            )}
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex space-x-8 overflow-x-auto">
            {tabs.map((tab) => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 whitespace-nowrap ${
                    activeTab === tab.id
                      ? `border-current text-white ${tab.color}`
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.name}
                </button>
              )
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Alerts */}
        {error && (
          <Alert className="mb-6 border-red-200 bg-red-50">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription className="text-red-700">{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="mb-6 border-green-200 bg-green-50">
            <CheckCircle className="h-4 w-4" />
            <AlertDescription className="text-green-700">{success}</AlertDescription>
          </Alert>
        )}

        {/* Tab Content */}
        {renderTabContent()}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-12">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="text-center space-y-2">
            <p className="text-sm text-gray-600">
              © 2024 لعبة العملات الرقمية - تم التطوير بواسطة Manus AI
            </p>
            <div className="flex items-center justify-center gap-2 text-sm text-orange-600">
              <AlertTriangle className="w-4 h-4" />
              <span>تحذير: هذا التطبيق يتعامل مع عملات مشفرة حقيقية. يرجى توخي الحذر.</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App
