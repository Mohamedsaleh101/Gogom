import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { 
  Coins, 
  Clock, 
  Zap, 
  AlertTriangle, 
  CheckCircle, 
  DollarSign,
  TrendingDown,
  History
} from 'lucide-react'

const RealWithdrawal = ({ 
  walletConnected, 
  userAddress, 
  gameData, 
  setGameData, 
  setError, 
  setSuccess,
  isLoading,
  setIsLoading 
}) => {
  const [withdrawalAmount, setWithdrawalAmount] = useState('')
  const [withdrawalType, setWithdrawalType] = useState('instant')
  const [withdrawalHistory, setWithdrawalHistory] = useState([])
  const [canWithdraw, setCanWithdraw] = useState(false)
  const [withdrawalFee, setWithdrawalFee] = useState(0)
  const [cooldownRemaining, setCooldownRemaining] = useState(0)

  // عناوين العقود (سيتم تحديثها بعد النشر)
  const CONTRACTS = {
    withdrawal: "0x0000000000000000000000000000000000000000", // سيتم تحديثه
    gameToken: "0x0000000000000000000000000000000000000000"  // سيتم تحديثه
  }

  // فحص إمكانية السحب
  useEffect(() => {
    if (walletConnected && withdrawalAmount) {
      checkWithdrawalEligibility()
      calculateFee()
    }
  }, [withdrawalAmount, withdrawalType, walletConnected])

  // فحص إمكانية السحب
  const checkWithdrawalEligibility = async () => {
    try {
      const amount = parseFloat(withdrawalAmount)
      
      // فحوصات أساسية
      if (amount < 10) {
        setCanWithdraw(false)
        setError('الحد الأدنى للسحب 10 عملات')
        return
      }
      
      if (amount > 1000) {
        setCanWithdraw(false)
        setError('الحد الأقصى للسحب اليومي 1000 عملة')
        return
      }
      
      if (amount > gameData.balance) {
        setCanWithdraw(false)
        setError('رصيد غير كافي')
        return
      }
      
      // محاكاة فحص فترة الانتظار
      const lastWithdrawal = localStorage.getItem(`lastWithdrawal_${userAddress}`)
      if (lastWithdrawal) {
        const timeDiff = Date.now() - parseInt(lastWithdrawal)
        const cooldown = 60 * 60 * 1000 // ساعة واحدة
        
        if (timeDiff < cooldown) {
          const remaining = Math.ceil((cooldown - timeDiff) / (60 * 1000))
          setCooldownRemaining(remaining)
          setCanWithdraw(false)
          setError(`يجب الانتظار ${remaining} دقيقة قبل السحب التالي`)
          return
        }
      }
      
      setCanWithdraw(true)
      setError('')
      
    } catch (error) {
      console.error('خطأ في فحص السحب:', error)
      setCanWithdraw(false)
    }
  }

  // حساب رسوم السحب
  const calculateFee = () => {
    const amount = parseFloat(withdrawalAmount) || 0
    
    if (withdrawalType === 'instant') {
      const fee = amount * 0.05 // 5% رسوم السحب الفوري
      setWithdrawalFee(fee)
    } else {
      setWithdrawalFee(0) // السحب المجدول بدون رسوم
    }
  }

  // تنفيذ السحب الفوري
  const executeInstantWithdrawal = async () => {
    if (!canWithdraw) return

    setIsLoading(true)
    setError('')

    try {
      const amount = parseFloat(withdrawalAmount)
      const fee = withdrawalFee
      const netAmount = amount - fee

      console.log('تنفيذ السحب الفوري:', { amount, fee, netAmount })

      // محاكاة العملية (سيتم استبدالها بالعقد الذكي)
      await new Promise(resolve => setTimeout(resolve, 3000))

      // تحديث الرصيد
      setGameData(prev => ({
        ...prev,
        balance: prev.balance - amount
      }))

      // حفظ وقت السحب
      localStorage.setItem(`lastWithdrawal_${userAddress}`, Date.now().toString())

      // إضافة للتاريخ
      const newWithdrawal = {
        id: Date.now(),
        amount: netAmount,
        fee: fee,
        type: 'instant',
        status: 'completed',
        timestamp: new Date().toISOString(),
        txHash: '0x' + Math.random().toString(16).substr(2, 64) // hash وهمي
      }

      setWithdrawalHistory(prev => [newWithdrawal, ...prev])
      
      setSuccess(`تم سحب ${netAmount.toFixed(2)} عملة بنجاح! 💰`)
      setWithdrawalAmount('')

    } catch (error) {
      console.error('خطأ في السحب:', error)
      setError('فشل في تنفيذ السحب')
    }

    setIsLoading(false)
  }

  // طلب السحب المجدول
  const requestScheduledWithdrawal = async () => {
    if (!canWithdraw) return

    setIsLoading(true)
    setError('')

    try {
      const amount = parseFloat(withdrawalAmount)

      console.log('طلب السحب المجدول:', { amount })

      // محاكاة العملية
      await new Promise(resolve => setTimeout(resolve, 2000))

      // إضافة للتاريخ كطلب معلق
      const newRequest = {
        id: Date.now(),
        amount: amount,
        fee: 0,
        type: 'scheduled',
        status: 'pending',
        timestamp: new Date().toISOString(),
        processTime: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 ساعة
      }

      setWithdrawalHistory(prev => [newRequest, ...prev])
      
      setSuccess(`تم إرسال طلب السحب المجدول. سيتم المعالجة خلال 24 ساعة.`)
      setWithdrawalAmount('')

    } catch (error) {
      console.error('خطأ في طلب السحب:', error)
      setError('فشل في إرسال طلب السحب')
    }

    setIsLoading(false)
  }

  // تحويل الوقت لصيغة مقروءة
  const formatTime = (timestamp) => {
    return new Date(timestamp).toLocaleString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  return (
    <div className="space-y-6">
      {/* تحذير السحب الحقيقي */}
      <Alert className="border-red-200 bg-red-50">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription className="text-red-700">
          <strong>تحذير:</strong> هذا نظام سحب حقيقي! العمليات نهائية ولا يمكن التراجع عنها.
          تأكد من صحة المبلغ قبل التأكيد.
        </AlertDescription>
      </Alert>

      {/* نموذج السحب */}
      <Card className="bg-green-50 border-green-200">
        <CardHeader>
          <CardTitle className="text-green-800 flex items-center gap-2">
            <DollarSign className="w-5 h-5" />
            سحب العملات الرقمية
          </CardTitle>
          <CardDescription className="text-green-600">
            اسحب عملاتك إلى محفظتك الخارجية
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* معلومات الرصيد */}
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-4 bg-white rounded border">
              <div className="text-2xl font-bold text-green-600">{gameData.balance}</div>
              <div className="text-sm text-gray-600">الرصيد المتاح</div>
            </div>
            <div className="text-center p-4 bg-white rounded border">
              <div className="text-2xl font-bold text-blue-600">{gameData.pendingRewards}</div>
              <div className="text-sm text-gray-600">مكافآت معلقة</div>
            </div>
          </div>

          {/* إدخال المبلغ */}
          <div>
            <Label className="text-sm font-medium text-gray-700">
              مبلغ السحب (GTK)
            </Label>
            <input
              type="number"
              value={withdrawalAmount}
              onChange={(e) => setWithdrawalAmount(e.target.value)}
              placeholder="أدخل المبلغ (10-1000)"
              min="10"
              max="1000"
              className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"
            />
            <div className="text-xs text-gray-500 mt-1">
              الحد الأدنى: 10 GTK | الحد الأقصى اليومي: 1000 GTK
            </div>
          </div>

          {/* نوع السحب */}
          <div>
            <Label className="text-sm font-medium text-gray-700 mb-3 block">
              نوع السحب
            </Label>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setWithdrawalType('instant')}
                className={`p-4 rounded border text-center ${
                  withdrawalType === 'instant' 
                    ? 'bg-orange-100 border-orange-300 text-orange-800' 
                    : 'bg-white border-gray-300'
                }`}
              >
                <Zap className="w-5 h-5 mx-auto mb-2" />
                <div className="font-semibold">سحب فوري</div>
                <div className="text-xs">رسوم 5%</div>
              </button>
              
              <button
                onClick={() => setWithdrawalType('scheduled')}
                className={`p-4 rounded border text-center ${
                  withdrawalType === 'scheduled' 
                    ? 'bg-blue-100 border-blue-300 text-blue-800' 
                    : 'bg-white border-gray-300'
                }`}
              >
                <Clock className="w-5 h-5 mx-auto mb-2" />
                <div className="font-semibold">سحب مجدول</div>
                <div className="text-xs">بدون رسوم - 24 ساعة</div>
              </button>
            </div>
          </div>

          {/* معلومات الرسوم */}
          {withdrawalAmount && (
            <div className="bg-gray-50 p-4 rounded border">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>المبلغ المطلوب:</span>
                  <span className="font-semibold">{withdrawalAmount} GTK</span>
                </div>
                <div className="flex justify-between">
                  <span>الرسوم:</span>
                  <span className="font-semibold">{withdrawalFee.toFixed(2)} GTK</span>
                </div>
                <div className="flex justify-between border-t pt-2">
                  <span>المبلغ الصافي:</span>
                  <span className="font-bold text-green-600">
                    {(parseFloat(withdrawalAmount || 0) - withdrawalFee).toFixed(2)} GTK
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* أزرار السحب */}
          <div className="space-y-3">
            {withdrawalType === 'instant' ? (
              <Button 
                onClick={executeInstantWithdrawal}
                disabled={!canWithdraw || isLoading || !walletConnected}
                className="w-full bg-orange-600 hover:bg-orange-700"
              >
                <Zap className="w-4 h-4 ml-2" />
                {isLoading ? 'جاري السحب...' : 'سحب فوري'}
              </Button>
            ) : (
              <Button 
                onClick={requestScheduledWithdrawal}
                disabled={!canWithdraw || isLoading || !walletConnected}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                <Clock className="w-4 h-4 ml-2" />
                {isLoading ? 'جاري الإرسال...' : 'طلب سحب مجدول'}
              </Button>
            )}

            {!walletConnected && (
              <p className="text-center text-red-500 text-sm">
                يرجى ربط المحفظة أولاً
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* تاريخ السحب */}
      <Card className="bg-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="w-5 h-5" />
            تاريخ السحب
          </CardTitle>
        </CardHeader>
        <CardContent>
          {withdrawalHistory.length === 0 ? (
            <p className="text-center text-gray-500 py-8">
              لا توجد عمليات سحب سابقة
            </p>
          ) : (
            <div className="space-y-3">
              {withdrawalHistory.map((withdrawal) => (
                <div key={withdrawal.id} className="flex items-center justify-between p-3 bg-gray-50 rounded border">
                  <div className="flex items-center gap-3">
                    {withdrawal.type === 'instant' ? (
                      <Zap className="w-4 h-4 text-orange-500" />
                    ) : (
                      <Clock className="w-4 h-4 text-blue-500" />
                    )}
                    <div>
                      <div className="font-semibold">{withdrawal.amount} GTK</div>
                      <div className="text-xs text-gray-500">
                        {formatTime(withdrawal.timestamp)}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge 
                      className={
                        withdrawal.status === 'completed' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-yellow-100 text-yellow-800'
                      }
                    >
                      {withdrawal.status === 'completed' ? 'مكتمل' : 'معلق'}
                    </Badge>
                    {withdrawal.fee > 0 && (
                      <div className="text-xs text-gray-500 mt-1">
                        رسوم: {withdrawal.fee.toFixed(2)} GTK
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default RealWithdrawal
