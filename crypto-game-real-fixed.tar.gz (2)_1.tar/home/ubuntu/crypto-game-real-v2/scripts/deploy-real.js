const { ethers } = require("hardhat");

async function main() {
    console.log("🚀 بدء نشر العقود الذكية الحقيقية...");
    
    // الحصول على المنشر
    const [deployer] = await ethers.getSigners();
    console.log("📝 نشر العقود بواسطة:", deployer.address);
    
    // فحص الرصيد
    const balance = await deployer.provider.getBalance(deployer.address);
    console.log("💰 رصيد المنشر:", ethers.formatEther(balance), "MATIC");
    
    if (balance < ethers.parseEther("0.1")) {
        console.log("⚠️  تحذير: رصيد منخفض! قد تحتاج المزيد من MATIC للنشر");
    }
    
    try {
        // 1. نشر عقد GameToken
        console.log("\n📦 نشر عقد GameToken...");
        const GameToken = await ethers.getContractFactory("SimpleGameToken");
        const gameToken = await GameToken.deploy();
        await gameToken.waitForDeployment();
        
        const gameTokenAddress = await gameToken.getAddress();
        console.log("✅ GameToken منشور على:", gameTokenAddress);
        
        // 2. نشر عقد Staking
        console.log("\n📦 نشر عقد Staking...");
        const Staking = await ethers.getContractFactory("SimpleStaking");
        const staking = await Staking.deploy(gameTokenAddress, gameTokenAddress);
        await staking.waitForDeployment();
        
        const stakingAddress = await staking.getAddress();
        console.log("✅ Staking منشور على:", stakingAddress);
        
        // 3. نشر عقد السحب الحقيقي
        console.log("\n📦 نشر عقد RealWithdrawal...");
        const RealWithdrawal = await ethers.getContractFactory("RealWithdrawal");
        const withdrawal = await RealWithdrawal.deploy(gameTokenAddress);
        await withdrawal.waitForDeployment();
        
        const withdrawalAddress = await withdrawal.getAddress();
        console.log("✅ RealWithdrawal منشور على:", withdrawalAddress);
        
        // 4. إعداد الأذونات
        console.log("\n🔧 إعداد الأذونات...");
        
        // إعطاء عقد السحب صلاحية نقل العملات
        await gameToken.approve(withdrawalAddress, ethers.parseEther("1000000"));
        console.log("✅ تم إعطاء أذونات السحب");
        
        // إعطاء عقد التخزين صلاحية إنتاج العملات
        await gameToken.setMinter(stakingAddress, true);
        console.log("✅ تم إعطاء أذونات التخزين");
        
        // 5. تمويل عقد السحب
        console.log("\n💰 تمويل عقد السحب...");
        const fundingAmount = ethers.parseEther("10"); // 10 MATIC للبداية
        
        if (balance > fundingAmount) {
            await withdrawal.fundContract({ value: fundingAmount });
            console.log("✅ تم تمويل عقد السحب بـ", ethers.formatEther(fundingAmount), "MATIC");
        } else {
            console.log("⚠️  رصيد غير كافي للتمويل");
        }
        
        // 6. طباعة ملخص النشر
        console.log("\n🎉 تم نشر جميع العقود بنجاح!");
        console.log("=" .repeat(50));
        console.log("📋 عناوين العقود:");
        console.log("GameToken:", gameTokenAddress);
        console.log("Staking:", stakingAddress);
        console.log("RealWithdrawal:", withdrawalAddress);
        console.log("=" .repeat(50));
        
        // 7. حفظ العناوين في ملف
        const contractAddresses = {
            gameToken: gameTokenAddress,
            staking: stakingAddress,
            withdrawal: withdrawalAddress,
            network: "polygon",
            deployer: deployer.address,
            deploymentTime: new Date().toISOString()
        };
        
        const fs = require('fs');
        fs.writeFileSync(
            './deployed-contracts.json', 
            JSON.stringify(contractAddresses, null, 2)
        );
        console.log("💾 تم حفظ عناوين العقود في deployed-contracts.json");
        
        // 8. تعليمات ما بعد النشر
        console.log("\n📋 الخطوات التالية:");
        console.log("1. تحديث عناوين العقود في التطبيق");
        console.log("2. اختبار العمليات على شبكة الاختبار");
        console.log("3. تدقيق العقود أمنياً");
        console.log("4. إضافة المزيد من التمويل حسب الحاجة");
        
        return contractAddresses;
        
    } catch (error) {
        console.error("❌ خطأ في النشر:", error);
        throw error;
    }
}

// تشغيل النشر
main()
    .then((addresses) => {
        console.log("\n🎊 النشر مكتمل بنجاح!");
        process.exit(0);
    })
    .catch((error) => {
        console.error("💥 فشل النشر:", error);
        process.exit(1);
    });
