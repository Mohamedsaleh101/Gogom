const { ethers } = require("hardhat");

async function main() {
    console.log("🚨🚨🚨 تحذير: النشر على الشبكة الرئيسية 🚨🚨🚨");
    console.log("⚠️  هذا سيكلف أموال حقيقية ولا يمكن التراجع!");
    console.log("💰 التكلفة المتوقعة: $200-500");
    console.log("🔴 المخاطر: عالية جداً");
    
    // تأكيد متعدد المراحل
    console.log("\n⏳ انتظار 15 ثانية للتفكير...");
    await new Promise(resolve => setTimeout(resolve, 15000));
    
    console.log("🤔 هل أنت متأكد؟ انتظار 10 ثوان إضافية...");
    await new Promise(resolve => setTimeout(resolve, 10000));
    
    console.log("🚀 بدء النشر على Polygon Mainnet...");
    
    try {
        // الحصول على المنشر
        const [deployer] = await ethers.getSigners();
        console.log("\n📝 عنوان المنشر:", deployer.address);
        
        // فحص الرصيد
        const balance = await deployer.provider.getBalance(deployer.address);
        const balanceInMatic = ethers.formatEther(balance);
        console.log("💰 رصيد MATIC:", balanceInMatic);
        
        // التحقق من كفاية الرصيد
        if (parseFloat(balanceInMatic) < 100) {
            throw new Error(`❌ رصيد غير كافي! الرصيد الحالي: ${balanceInMatic} MATIC. تحتاج 100+ MATIC للنشر الآمن`);
        }
        
        // فحص الشبكة
        const network = await deployer.provider.getNetwork();
        console.log("🌐 الشبكة:", network.name, "Chain ID:", network.chainId.toString());
        
        if (network.chainId.toString() !== "137") {
            throw new Error("❌ شبكة خاطئة! يجب أن تكون Polygon Mainnet (Chain ID: 137)");
        }
        
        console.log("✅ جميع الفحوصات نجحت. بدء النشر...\n");
        
        // إعدادات الغاز للشبكة الرئيسية
        const gasSettings = {
            gasPrice: ethers.parseUnits("50", "gwei"), // 50 gwei
            gasLimit: 5000000
        };
        
        let totalGasUsed = 0;
        let deploymentCost = 0;
        
        // 1. نشر GameToken
        console.log("📦 نشر عقد GameToken...");
        const GameToken = await ethers.getContractFactory("SimpleGameToken");
        const gameToken = await GameToken.deploy(gasSettings);
        
        const gameTokenReceipt = await gameToken.deploymentTransaction().wait();
        totalGasUsed += gameTokenReceipt.gasUsed;
        deploymentCost += gameTokenReceipt.gasUsed * gasSettings.gasPrice;
        
        const gameTokenAddress = await gameToken.getAddress();
        console.log("✅ GameToken منشور على:", gameTokenAddress);
        console.log("⛽ غاز مستخدم:", gameTokenReceipt.gasUsed.toString());
        
        // انتظار للتأكد من النشر
        await new Promise(resolve => setTimeout(resolve, 5000));
        
        // 2. نشر Staking Contract
        console.log("\n📦 نشر عقد Staking...");
        const Staking = await ethers.getContractFactory("SimpleStaking");
        const staking = await Staking.deploy(
            gameTokenAddress,
            gameTokenAddress,
            gasSettings
        );
        
        const stakingReceipt = await staking.deploymentTransaction().wait();
        totalGasUsed += stakingReceipt.gasUsed;
        deploymentCost += stakingReceipt.gasUsed * gasSettings.gasPrice;
        
        const stakingAddress = await staking.getAddress();
        console.log("✅ Staking منشور على:", stakingAddress);
        console.log("⛽ غاز مستخدم:", stakingReceipt.gasUsed.toString());
        
        // انتظار للتأكد من النشر
        await new Promise(resolve => setTimeout(resolve, 5000));
        
        // 3. نشر RealWithdrawal Contract
        console.log("\n📦 نشر عقد RealWithdrawal...");
        const RealWithdrawal = await ethers.getContractFactory("RealWithdrawal");
        const withdrawal = await RealWithdrawal.deploy(
            gameTokenAddress,
            gasSettings
        );
        
        const withdrawalReceipt = await withdrawal.deploymentTransaction().wait();
        totalGasUsed += withdrawalReceipt.gasUsed;
        deploymentCost += withdrawalReceipt.gasUsed * gasSettings.gasPrice;
        
        const withdrawalAddress = await withdrawal.getAddress();
        console.log("✅ RealWithdrawal منشور على:", withdrawalAddress);
        console.log("⛽ غاز مستخدم:", withdrawalReceipt.gasUsed.toString());
        
        // 4. إعداد الأذونات
        console.log("\n🔧 إعداد الأذونات والإعدادات...");
        
        // إعطاء عقد السحب صلاحية نقل العملات
        console.log("🔑 إعطاء أذونات السحب...");
        const approveTx = await gameToken.approve(
            withdrawalAddress, 
            ethers.parseEther("1000000"),
            { gasPrice: gasSettings.gasPrice, gasLimit: 100000 }
        );
        await approveTx.wait();
        console.log("✅ تم إعطاء أذونات السحب");
        
        // إعطاء عقد التخزين صلاحية إنتاج العملات
        console.log("🔑 إعطاء أذونات التخزين...");
        const minterTx = await gameToken.setMinter(
            stakingAddress, 
            true,
            { gasPrice: gasSettings.gasPrice, gasLimit: 100000 }
        );
        await minterTx.wait();
        console.log("✅ تم إعطاء أذونات التخزين");
        
        // 5. تمويل عقد السحب
        console.log("\n💰 تمويل عقد السحب...");
        const fundingAmount = ethers.parseEther("1000"); // 1000 MATIC
        
        if (parseFloat(balanceInMatic) > 1100) { // التأكد من وجود رصيد كافي
            const fundTx = await withdrawal.fundContract({ 
                value: fundingAmount,
                gasPrice: gasSettings.gasPrice,
                gasLimit: 100000
            });
            await fundTx.wait();
            console.log("✅ تم تمويل عقد السحب بـ 1000 MATIC");
        } else {
            console.log("⚠️  رصيد غير كافي للتمويل. يرجى إضافة MATIC يدوياً لاحقاً");
        }
        
        // 6. حساب التكلفة الإجمالية
        const totalCostInMatic = ethers.formatEther(deploymentCost);
        const maticPrice = 0.8; // سعر تقريبي للـ MATIC
        const totalCostInUSD = parseFloat(totalCostInMatic) * maticPrice;
        
        console.log("\n💸 ملخص التكاليف:");
        console.log("⛽ إجمالي الغاز المستخدم:", totalGasUsed.toString());
        console.log("💰 التكلفة بالـ MATIC:", totalCostInMatic);
        console.log("💵 التكلفة التقريبية بالدولار: $", totalCostInUSD.toFixed(2));
        
        // 7. حفظ معلومات النشر
        const deploymentInfo = {
            network: "polygon-mainnet",
            chainId: 137,
            deployer: deployer.address,
            deploymentTime: new Date().toISOString(),
            contracts: {
                gameToken: {
                    address: gameTokenAddress,
                    gasUsed: gameTokenReceipt.gasUsed.toString()
                },
                staking: {
                    address: stakingAddress,
                    gasUsed: stakingReceipt.gasUsed.toString()
                },
                withdrawal: {
                    address: withdrawalAddress,
                    gasUsed: withdrawalReceipt.gasUsed.toString()
                }
            },
            costs: {
                totalGasUsed: totalGasUsed.toString(),
                totalCostMatic: totalCostInMatic,
                totalCostUSD: totalCostInUSD.toFixed(2)
            },
            funded: parseFloat(balanceInMatic) > 1100,
            fundingAmount: "1000 MATIC"
        };
        
        // حفظ في ملف
        const fs = require('fs');
        fs.writeFileSync(
            './mainnet-deployment.json',
            JSON.stringify(deploymentInfo, null, 2)
        );
        
        // 8. طباعة النتائج النهائية
        console.log("\n🎉🎉🎉 النشر مكتمل بنجاح! 🎉🎉🎉");
        console.log("=" .repeat(60));
        console.log("📋 عناوين العقود على Polygon Mainnet:");
        console.log("🪙 GameToken (GTK):", gameTokenAddress);
        console.log("🏦 Staking Contract:", stakingAddress);
        console.log("💸 Withdrawal Contract:", withdrawalAddress);
        console.log("=" .repeat(60));
        
        console.log("\n🔗 روابط التحقق على PolygonScan:");
        console.log("🪙 GameToken:", `https://polygonscan.com/address/${gameTokenAddress}`);
        console.log("🏦 Staking:", `https://polygonscan.com/address/${stakingAddress}`);
        console.log("💸 Withdrawal:", `https://polygonscan.com/address/${withdrawalAddress}`);
        
        console.log("\n📋 الخطوات التالية:");
        console.log("1. ✅ تحديث عناوين العقود في التطبيق");
        console.log("2. ✅ التحقق من العقود على PolygonScan");
        console.log("3. ✅ اختبار العمليات بمبالغ صغيرة");
        console.log("4. ✅ مراقبة العقود باستمرار");
        console.log("5. ✅ إعداد تنبيهات الأمان");
        
        console.log("\n⚠️  تذكيرات مهمة:");
        console.log("🔴 هذه عقود حقيقية تتعامل مع أموال فعلية");
        console.log("🔴 راقب رصيد عقد السحب باستمرار");
        console.log("🔴 كن مستعداً لتفعيل الوضع الطارئ عند الحاجة");
        console.log("🔴 احتفظ بنسخ احتياطية من جميع المعلومات");
        
        console.log("\n💾 تم حفظ جميع المعلومات في mainnet-deployment.json");
        
        return deploymentInfo;
        
    } catch (error) {
        console.error("\n💥 خطأ في النشر:");
        console.error("❌", error.message);
        
        if (error.message.includes("insufficient funds")) {
            console.log("\n💡 الحل: أضف المزيد من MATIC إلى محفظتك");
        } else if (error.message.includes("gas")) {
            console.log("\n💡 الحل: زد من حد الغاز أو سعر الغاز");
        } else if (error.message.includes("network")) {
            console.log("\n💡 الحل: تأكد من الاتصال بشبكة Polygon الصحيحة");
        }
        
        throw error;
    }
}

// تشغيل النشر مع معالجة الأخطاء
main()
    .then((deploymentInfo) => {
        console.log("\n🎊 النشر على الشبكة الرئيسية مكتمل!");
        console.log("🚀 اللعبة جاهزة للاستخدام مع عملات حقيقية!");
        process.exit(0);
    })
    .catch((error) => {
        console.error("\n💥 فشل النشر على الشبكة الرئيسية:");
        console.error(error);
        console.log("\n🔄 يمكنك المحاولة مرة أخرى بعد إصلاح المشكلة");
        process.exit(1);
    });
