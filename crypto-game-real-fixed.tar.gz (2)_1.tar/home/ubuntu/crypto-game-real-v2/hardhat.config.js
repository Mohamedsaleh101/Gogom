require("@nomicfoundation/hardhat-toolbox");

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: {
    version: "0.8.19",
    settings: {
      optimizer: {
        enabled: true,
        runs: 200
      }
    }
  },
  networks: {
    // شبكة الاختبار - Mumbai
    mumbai: {
      url: "https://rpc-mumbai.maticvigil.com/",
      accounts: [], // أضف مفتاحك الخاص هنا للاختبار
      chainId: 80001,
      gasPrice: 20000000000, // 20 gwei
    },
    
    // الشبكة الرئيسية - Polygon ⚠️ خطير!
    polygon: {
      url: "https://polygon-rpc.com/", 
      accounts: [], // ⚠️ أضف مفتاحك الخاص هنا (احذفه بعد النشر!)
      chainId: 137,
      gasPrice: 50000000000, // 50 gwei
      gas: 6000000,
      timeout: 60000,
    },
    
    // شبكة محلية للاختبار
    localhost: {
      url: "http://127.0.0.1:8545",
      chainId: 31337,
    }
  },
  
  // إعدادات التحقق من العقود على PolygonScan
  etherscan: {
    apiKey: {
      polygon: "", // أضف مفتاح PolygonScan API هنا
      polygonMumbai: ""
    }
  },
  
  mocha: {
    timeout: 60000
  }
};

// ⚠️⚠️⚠️ تحذيرات أمنية مهمة ⚠️⚠️⚠️
//
// للنشر على الشبكة الرئيسية:
// 1. أضف مفتاحك الخاص في accounts: ["0xYOUR_PRIVATE_KEY"]
// 2. تأكد من وجود 100+ MATIC في محفظتك
// 3. شغل: npx hardhat run scripts/deploy-mainnet.js --network polygon
// 4. احذف المفتاح الخاص فوراً بعد النشر!
//
// 🚨 لا تشارك هذا الملف إذا كان يحتوي على مفتاحك الخاص!
