# 🚨 النشر على الشبكة الرئيسية - MAINNET DEPLOYMENT

## ⚠️ تحذيرات شديدة - اقرأ بعناية!

### 🔴 **مخاطر عالية جداً:**
- **أموال حقيقية** - كل عملية تكلف أموال فعلية
- **لا تراجع** - العمليات نهائية ولا يمكن إلغاؤها
- **مسؤولية كاملة** - أنت مسؤول عن أي خسائر
- **لا ضمانات** - قد تفقد كل أموالك

### 💰 **التكاليف المتوقعة:**

#### رسوم النشر:
- **نشر GameToken**: ~$20-50
- **نشر StakingContract**: ~$30-70  
- **نشر RealWithdrawal**: ~$40-80
- **إعداد الأذونات**: ~$10-30
- **المجموع**: **$100-230**

#### رأس المال المطلوب:
- **تمويل عقد السحب**: $10,000+ (للمكافآت)
- **احتياطي السيولة**: $5,000+ (للسحبات)
- **رسوم التشغيل**: $1,000+ (شهرياً)

## 🛠️ إعداد النشر على Polygon الرئيسية

### 1. تحديث ملف hardhat.config.js

```javascript
require("@nomicfoundation/hardhat-toolbox");

module.exports = {
  solidity: "0.8.19",
  networks: {
    polygon: {
      url: "https://polygon-rpc.com/", // أو استخدم Alchemy/Infura
      accounts: ["YOUR_PRIVATE_KEY_HERE"], // ⚠️ احذف هذا بعد النشر!
      gasPrice: 50000000000, // 50 gwei
    }
  },
  etherscan: {
    apiKey: "YOUR_POLYGONSCAN_API_KEY" // للتحقق من العقود
  }
};
```

### 2. إعداد المحفظة للنشر

#### متطلبات المحفظة:
- **رصيد MATIC**: 500+ MATIC (~$300-500)
- **محفظة منفصلة**: لا تستخدم محفظتك الشخصية
- **مفتاح خاص آمن**: احتفظ به في مكان آمن

#### الحصول على MATIC:
- **Binance**: شراء وسحب إلى محفظتك
- **Coinbase**: شراء مباشر
- **UniSwap**: تبديل من عملات أخرى

### 3. نص النشر المحدث

```javascript
// scripts/deploy-mainnet.js
const { ethers } = require("hardhat");

async function main() {
    console.log("🚨 نشر على الشبكة الرئيسية - POLYGON MAINNET");
    console.log("⚠️  تحذير: هذا سيكلف أموال حقيقية!");
    
    // تأكيد النشر
    console.log("انتظار 10 ثوان للتأكيد...");
    await new Promise(resolve => setTimeout(resolve, 10000));
    
    const [deployer] = await ethers.getSigners();
    console.log("المنشر:", deployer.address);
    
    const balance = await deployer.provider.getBalance(deployer.address);
    console.log("الرصيد:", ethers.formatEther(balance), "MATIC");
    
    if (balance < ethers.parseEther("100")) {
        throw new Error("رصيد غير كافي! تحتاج 100+ MATIC للنشر الآمن");
    }
    
    // نشر العقود
    console.log("🚀 بدء النشر...");
    
    // 1. GameToken
    const GameToken = await ethers.getContractFactory("SimpleGameToken");
    const gameToken = await GameToken.deploy({
        gasLimit: 3000000,
        gasPrice: ethers.parseUnits("50", "gwei")
    });
    await gameToken.waitForDeployment();
    console.log("✅ GameToken:", await gameToken.getAddress());
    
    // 2. Staking
    const Staking = await ethers.getContractFactory("SimpleStaking");
    const staking = await Staking.deploy(
        await gameToken.getAddress(),
        await gameToken.getAddress(),
        {
            gasLimit: 4000000,
            gasPrice: ethers.parseUnits("50", "gwei")
        }
    );
    await staking.waitForDeployment();
    console.log("✅ Staking:", await staking.getAddress());
    
    // 3. RealWithdrawal
    const RealWithdrawal = await ethers.getContractFactory("RealWithdrawal");
    const withdrawal = await RealWithdrawal.deploy(
        await gameToken.getAddress(),
        {
            gasLimit: 5000000,
            gasPrice: ethers.parseUnits("50", "gwei")
        }
    );
    await withdrawal.waitForDeployment();
    console.log("✅ RealWithdrawal:", await withdrawal.getAddress());
    
    // تمويل عقد السحب
    const fundingAmount = ethers.parseEther("1000"); // 1000 MATIC
    await withdrawal.fundContract({ 
        value: fundingAmount,
        gasLimit: 100000,
        gasPrice: ethers.parseUnits("50", "gwei")
    });
    console.log("💰 تم تمويل عقد السحب بـ 1000 MATIC");
    
    // حفظ العناوين
    const addresses = {
        gameToken: await gameToken.getAddress(),
        staking: await staking.getAddress(),
        withdrawal: await withdrawal.getAddress(),
        network: "polygon-mainnet",
        deployer: deployer.address,
        deploymentTime: new Date().toISOString(),
        totalCost: "~$200-500 USD"
    };
    
    require('fs').writeFileSync(
        './mainnet-contracts.json',
        JSON.stringify(addresses, null, 2)
    );
    
    console.log("🎉 النشر مكتمل!");
    console.log("📋 العناوين محفوظة في mainnet-contracts.json");
    
    return addresses;
}

main().catch(console.error);
```

### 4. تحديث التطبيق للشبكة الرئيسية

```javascript
// في RealWithdrawal.jsx
const MAINNET_CONTRACTS = {
    withdrawal: "0x...", // عنوان عقد السحب الحقيقي
    gameToken: "0x...",  // عنوان عقد العملة الحقيقي
    network: "polygon",
    chainId: 137
};

// التحقق من الشبكة
const checkNetwork = async () => {
    if (window.ethereum) {
        const chainId = await window.ethereum.request({ method: 'eth_chainId' });
        if (chainId !== '0x89') { // 137 في hex
            await window.ethereum.request({
                method: 'wallet_switchEthereumChain',
                params: [{ chainId: '0x89' }],
            });
        }
    }
};
```

## 🚀 خطوات النشر الفعلي

### 1. التحضير النهائي
```bash
# تأكد من تجميع العقود
npx hardhat compile

# فحص الأخطاء
npx hardhat test

# تحقق من الرصيد
npx hardhat run scripts/check-balance.js --network polygon
```

### 2. النشر الفعلي
```bash
# ⚠️ هذا سيكلف أموال حقيقية!
npx hardhat run scripts/deploy-mainnet.js --network polygon
```

### 3. التحقق من العقود
```bash
# التحقق على PolygonScan
npx hardhat verify --network polygon CONTRACT_ADDRESS
```

## 📊 مراقبة ما بعد النشر

### مؤشرات مهمة:
- **رصيد عقد السحب**: يجب مراقبته باستمرار
- **عدد المستخدمين**: تتبع النمو
- **حجم العمليات**: مراقبة السيولة
- **الأخطاء**: تسجيل المشاكل

### تنبيهات الطوارئ:
- **نفاد السيولة**: إضافة أموال فوراً
- **هجمات محتملة**: تفعيل الوضع الطارئ
- **أخطاء في العقود**: إيقاف العمليات

## 🆘 خطة الطوارئ

### في حالة المشاكل:
1. **تفعيل الوضع الطارئ** في العقد
2. **إيقاف التطبيق** مؤقتاً
3. **إخطار المستخدمين** فوراً
4. **تحليل المشكلة** مع خبراء
5. **إصلاح وإعادة التشغيل**

### أرقام الطوارئ:
- **دعم تقني**: متاح 24/7
- **خبراء أمان**: للاستشارات العاجلة
- **محامي تقني**: للمسائل القانونية

## 💡 نصائح للنجاح

### قبل النشر:
- ✅ **اختبار شامل** على شبكة الاختبار
- ✅ **تدقيق أمني** من خبراء
- ✅ **خطة عمل** واضحة
- ✅ **فريق دعم** جاهز

### بعد النشر:
- 📊 **مراقبة مستمرة** للعمليات
- 💰 **إدارة السيولة** بعناية
- 🛡️ **تحديثات أمنية** دورية
- 📞 **دعم المستخدمين** السريع

## ⚖️ المسؤوليات القانونية

### تحذيرات إجبارية:
- **إخلاء مسؤولية** واضح
- **تحذيرات المخاطر** في كل مكان
- **شروط الاستخدام** مفصلة
- **سياسة الخصوصية** شاملة

### متطلبات قانونية:
- **ترخيص مالي** (حسب البلد)
- **ضرائب العملات المشفرة**
- **قوانين مكافحة غسيل الأموال**
- **حماية بيانات المستخدمين**

---

## 🎯 القرار النهائي

### إذا كنت مصمماً على المتابعة:

1. **اقرأ كل التحذيرات** مرة أخرى
2. **احصل على تدقيق أمني** ($5,000-15,000)
3. **جهز رأس المال** ($15,000+)
4. **استشر محامي** متخصص
5. **ابدأ بمبالغ صغيرة** للاختبار

### الأمر متروك لك، لكن تذكر:
- **المخاطر عالية جداً** 🚨
- **المسؤولية كاملة عليك** ⚖️
- **لا ضمانات على النجاح** 📉
- **قد تفقد كل شيء** 💸

**هل أنت متأكد من المتابعة؟** 🤔
